<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.oceanlink.beans.Cliente" %>
<%@ page import="com.oceanlink.beans.Servicio" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.ArrayList" %>
<jsp:useBean id="listaClientes" type="java.util.ArrayList<com.oceanlink.beans.Cliente>" scope="request" />
<jsp:useBean id="listaServicios" type="java.util.ArrayList<com.oceanlink.beans.Servicio>" scope="request" />
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WaveWires - Clientes Empresariales</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">

<div class="row g-0">
  <jsp:include page="sidebar.jsp"/>

  <main class="col p-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h2 class="h3 fw-bold text-dark m-0">Clientes Empresariales</h2>
        <small class="text-muted">Gestiona nuestros clientes</small>
      </div>
      <button type="button" class="btn btn-dark btn-sm px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalRegistrarCliente">
        <i class="bi bi-plus-lg me-1"></i> Registrar cliente
      </button>
    </div>

    <% if ("creado".equals(request.getParameter("msg"))) { %>
    <div class="alert alert-success">Cliente registrado. Empieza como Inactivo hasta que tenga un servicio activo.</div>
    <% } %>
    <% if ("guardado".equals(request.getParameter("msg"))) { %>
    <div class="alert alert-success">Cambios guardados.</div>
    <% } %>
    <% if ("borrado".equals(request.getParameter("msg"))) { %>
    <div class="alert alert-success">Cliente eliminado.</div>
    <% } %>
    <% if ("vacio".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">Completa la razón social y el correo.</div>
    <% } %>
    <% if ("largo".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">La razón social y el correo pueden tener como máximo 100 caracteres.</div>
    <% } %>
    <% if ("enUso".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">No se puede eliminar el cliente porque tiene solicitudes o servicios registrados.</div>
    <% } %>
    <% if ("ruc".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">El RUC debe tener 11 números.</div>
    <% } %>
    <% if ("correo".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">El correo no es válido.</div>
    <% } %>
    <% if ("rucRepetido".equals(request.getParameter("error"))) { %>
    <div class="alert alert-danger">Ya existe un cliente con ese RUC.</div>
    <% } %>

    <div class="card shadow-sm border-0 p-3">

      <form method="GET" action="<%=request.getContextPath()%>/ClienteServlet" class="row mb-3">
        <div class="col-md-4">
          <input type="text" name="buscar" class="form-control" placeholder="Buscar cliente, razón social o RUC..."
                 value="<%=request.getParameter("buscar") != null ? request.getParameter("buscar") : ""%>">
        </div>
      </form>

      <div class="table-responsive">
        <table class="table table-hover align-middle mb-3">
          <thead class="table-light">
          <tr>
            <th style="width: 10%;">Identificador</th>
            <th style="width: 18%;">Razón Social</th>
            <th style="width: 11%;">RUC</th>
            <th style="width: 17%;">Correo</th>
            <th style="width: 12%;">Servicios Contratados</th>
            <th style="width: 12%;">Fecha de cliente registrado</th>
            <th style="width: 8%;">Estado</th>
            <th style="width: 12%;" class="text-center">Acción</th>
          </tr>
          </thead>
          <tbody>
          <% for (Cliente c : listaClientes) {
               String colorBadge = "bg-success-subtle text-success border border-success-subtle";
               if (c.getEstado() != null && c.getEstado().equalsIgnoreCase("Inactivo")) {
                   colorBadge = "bg-secondary-subtle text-secondary border border-secondary-subtle";
               }
          %>
          <tr>
            <td class="fw-medium"><%=c.getIdentificador()%></td>
            <td><%=c.getRazonSocial()%></td>
            <td><%=c.getRuc()%></td>
            <td><%=c.getCorreo()%></td>
            <td>
              <button type="button" class="btn btn-sm btn-outline-secondary px-3" data-bs-toggle="modal" data-bs-target="#modalServicios<%=c.getIdCliente()%>">
                Detalles
              </button>
            </td>
            <td class="text-secondary"><%=c.getFechaRegistro()%></td>
            <td>
              <span class="badge <%=colorBadge%>"><%=c.getEstado()%></span>
            </td>
            <td class="text-center text-nowrap">
              <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditar<%=c.getIdCliente()%>">
                Editar
              </button>
              <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalBorrar<%=c.getIdCliente()%>">
                <i class="bi bi-trash"></i> Eliminar
              </button>
            </td>
          </tr>
          <% } %>
          </tbody>
        </table>
      </div>

    </div>
  </main>
</div>

<%
   SimpleDateFormat sdfModal = new SimpleDateFormat("dd/MM/yyyy");
   for (Cliente c : listaClientes) {
     ArrayList<Servicio> serviciosDelCliente = new ArrayList<>();
     if (listaServicios != null) {
       for (Servicio sv : listaServicios) {
         if (sv.getIdCliente() == c.getIdCliente()) {
           serviciosDelCliente.add(sv);
         }
       }
     }
%>
<div class="modal fade" id="modalServicios<%=c.getIdCliente()%>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">

      <div class="modal-header border-bottom py-3 px-4">
        <h6 class="modal-title fw-bold text-dark m-0">Servicios contratados - <%=c.getRazonSocial()%></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>

      <div class="modal-body p-4">
        <% if (serviciosDelCliente.isEmpty()) { %>
          <div class="p-3 bg-light text-center rounded border text-muted small">
            Sin servicios contratados actualmente.
          </div>
        <% } else { %>
          <div class="list-group">
            <% for (Servicio sv : serviciosDelCliente) {
                 String cad = sv.getFechaCaducidad() != null ? sdfModal.format(sv.getFechaCaducidad()) : "-";
                 int cap = sv.getCapacidad() != null ? sv.getCapacidad().intValue() : 0;
                 String cod = (sv.getIdentificador() != null && !sv.getIdentificador().trim().isEmpty())
                              ? sv.getIdentificador() : "Servicio " + sv.getIdServicio();
                 String segTexto = sv.getIdSegmento() > 0 ? "Segmento " + sv.getIdSegmento() : "No asignado";
            %>
              <div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-semibold"><%=cod%></div>
                  <small class="text-muted"><%=segTexto%> &bull; Vence: <%=cad%></small>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle"><%=cap%> Gbps</span>
              </div>
            <% } %>
          </div>
        <% } %>
      </div>

      <div class="modal-footer border-top-0 pt-0 px-4 pb-4">
        <button type="button" class="btn btn-secondary btn-sm px-4" data-bs-dismiss="modal">Cerrar</button>
      </div>

    </div>
  </div>
</div>
<% } %>

<% for (Cliente c : listaClientes) { %>
<div class="modal fade" id="modalEditar<%=c.getIdCliente()%>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">

      <div class="modal-header border-bottom py-3 px-4">
        <h5 class="modal-title fw-bold m-0">Editar <%=c.getIdentificador()%></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>

      <form method="POST" action="<%=request.getContextPath()%>/ClienteServlet?action=actualizar">
        <input type="hidden" name="idCliente" value="<%=c.getIdCliente()%>">
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Razón social</label>
            <input type="text" name="razonSocial" class="form-control" maxlength="100" value="<%=c.getRazonSocial()%>" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">RUC</label>
            <input type="text" name="ruc" class="form-control" maxlength="11" value="<%=c.getRuc()%>" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Correo de contacto</label>
            <input type="email" name="correo" class="form-control" maxlength="100" value="<%=c.getCorreo()%>" required>
          </div>
        </div>

        <div class="modal-footer border-top-0 pt-0 px-4 pb-4">
          <button type="button" class="btn btn-outline-secondary px-3" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-dark px-3">Guardar cambios</button>
        </div>
      </form>

    </div>
  </div>
</div>

<div class="modal fade" id="modalBorrar<%=c.getIdCliente()%>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header border-bottom py-3 px-4">
        <h6 class="modal-title fw-bold text-dark m-0">Eliminar cliente</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body p-4">
        ¿Estás seguro de que deseas eliminar a <b><%=c.getRazonSocial()%></b>?
      </div>
      <div class="modal-footer border-top-0 pt-0 px-4 pb-4">
        <button type="button" class="btn btn-primary px-3" data-bs-dismiss="modal">Cancelar</button>
        <a href="<%=request.getContextPath()%>/ClienteServlet?action=borrar&id=<%=c.getIdCliente()%>" class="btn btn-outline-danger px-3">Sí, eliminar</a>
      </div>
    </div>
  </div>
</div>
<% } %>

<div class="modal fade" id="modalRegistrarCliente" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">

      <div class="modal-header border-bottom py-3 px-4">
        <h5 class="modal-title fw-bold m-0">Registrar Cliente</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>

      <form method="POST" action="<%=request.getContextPath()%>/ClienteServlet?action=crear">
        <div class="modal-body p-4">
          <h6 class="fw-bold text-dark border-bottom pb-2 mb-3">Datos</h6>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Razón social</label>
            <input type="text" name="razonSocial" class="form-control" maxlength="100" placeholder="Escribe el nombre de la empresa" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">RUC</label>
            <input type="text" name="ruc" class="form-control" maxlength="11" placeholder="11 números" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Correo de contacto</label>
            <input type="email" name="correo" class="form-control" maxlength="100" placeholder="contacto@empresa.pe" required>
          </div>
        </div>

        <div class="modal-footer border-top-0 pt-0 px-4 pb-4">
          <button type="button" class="btn btn-outline-secondary px-3" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-dark px-3">Guardar cliente</button>
        </div>
      </form>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>